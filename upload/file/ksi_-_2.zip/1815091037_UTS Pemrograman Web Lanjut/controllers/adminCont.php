<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class adminCont extends Controller
{
    //
    public function index()
    {
        if (Session::get('login')) {
            return redirect('/home');
        } else {
            return view('admin/index');
        }
    }
    public function kegiatan()
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            $kegiatan = DB::table('kegiatan')->get();
            return view('admin/kegiatan', ["kegiatan" => $kegiatan]);
        }
    }
    public function tambah()
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            return view('admin/tambah');
        }
    }
    public function detail($id)
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            $anggota = DB::table('anggota')->where('kegiatan_id', '=', $id)->get();
            $kegiatan = DB::table('kegiatan')->where('id', '=', $id)->get();
            return view('/admin/detail', ['var_anggota' => $anggota, 'var_kegiatan' => $kegiatan]);
        }
    }
    public function tambahKegiatan(Request $req)
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            $nama = $req->nama_kegiatan;
            $tanggal = $req->tanggal;
            $jumlah = $req->jumlah_pendaftar;
            // menghubungkan kedatabase
            DB::table('kegiatan')->insert(['nama' => $nama, 'tanggal' => $tanggal, 'kuota' => $jumlah, 'sisa' => '0', 'status' => 'buka']);
            session()->flash('berhasil', 'Data Berhasil Ditambahkan');
            return redirect('/kegiatan');
        }
    }
    public function status($id)
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            $data = DB::table('kegiatan')->where('id', '=', $id)->get();
            $data = $data->toArray();
            $tutup = "tutup";
            $buka = "buka";
            if ($data[0]->status == "buka") {
                DB::table('kegiatan')->where('id', '=', $id)->update(['status' => $tutup]);
                return redirect('/kegiatan');
            } else {
                DB::table('kegiatan')->where('id', '=', $id)->update(['status' => $buka]);
                return redirect('/kegiatan');
            }
        }
    }
    public function home()
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            return view('/admin/home');
        }
    }
    public function prosesLogin(Request $req)
    {
        if (Session::get('login')) {
            return redirect('/home');
        } else {
            $id = $req->username;
            $pass = $req->password;
            $data = DB::table('admin')->where('nim', '=', $id)->first();
            if ($data) {
                if (Hash::check($pass, $data->password)) {
                    Session::put('nim', $data->nim);
                    Session::put('nama', $data->nama);
                    Session::put('jabatan', $data->jabatan);
                    Session::put('login', TRUE);
                    return redirect('/home');
                } else {
                    session()->flash('gagal', 'Username atau Password Salah!!');
                    return redirect('/admin');
                }
            } else {
                session()->flash('gagal', 'Username atau Password Salah!!');
                return redirect('/admin');
            }
        }
    }
    public function hapus($id)
    {
        if (!Session::get('login')) {
            session()->flash('gagal', 'Kamu Harus Login Terlebih Dahulu!!');
            return redirect('/admin');
        } else {
            DB::table('kegiatan')->where('id', '=', $id)->delete();
            DB::table('anggota')->where('kegiatan_id', '=', $id)->delete();
            session()->flash('berhasil', 'Data Berhasil Dihapus');
            return redirect('/kegiatan');
        }
    }
    public function logout()
    {
        Session::flush();
        session()->flash('berhasil', 'Data Berhasil Dihapus');
        return redirect('/admin');
    }
}