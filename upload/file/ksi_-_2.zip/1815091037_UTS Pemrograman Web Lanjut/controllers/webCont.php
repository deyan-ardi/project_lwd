<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class webCont extends Controller
{
    public function index()
    {
        return view('welcome');
    }
    public function daftar()
    {
        $kegiatan = DB::table('kegiatan')->get();
        return view('daftar', ["var_kegiatan" => $kegiatan]);
    }
    public function pendaftaran(Request $req)
    {
        $nim = $req->nim;
        $nama = $req->nama_lengkap;
        $prodi = $req->prodi;
        $opsi = $req->panitia; //dalam bentuk id option
        // Panggil Data Tabel Kegiatan Jika Id Kegiatan Sama Dengan Opsi
        $kegiatan = DB::table('kegiatan')->where('id', '=', $opsi)->get();
        // Ubah Jadi Array
        $kegiatan = $kegiatan->toArray();
        if ($kegiatan[0]->sisa >= $kegiatan[0]->kuota) {
            session()->flash('gagal', 'Kepanitiaan Yang Dipilih Sudah Penuh, Data Gagal Ditambahkan!!');
            return redirect('/daftar');
        } else {
            // Input Data Pendaftaran Ke Database
            DB::table('anggota')->insert(['nim' => $nim, 'nama' => $nama, 'prodi' => $prodi, 'kegiatan_id' => $opsi]);
            // Hitung Pada Tabel Anggota Berapakah Jumlah Anggota Yang Memiliki Kegiatan_id Sama Dengan Id Kegiatan
            $row = DB::table('anggota')->where('kegiatan_id', '=', $kegiatan[0]->id)->get();
            $hitung = count($row);
            // Update Kolom Sisa Pada Tabel Kegiatan
            DB::table('kegiatan')->where('id', '=', $opsi)->update(['sisa' => $hitung]);
            session()->flash('berhasil', 'Data Berhasil Ditambahkan');
            // Redirect Ke Daftar
            return redirect('/daftar');
        }
    }
}