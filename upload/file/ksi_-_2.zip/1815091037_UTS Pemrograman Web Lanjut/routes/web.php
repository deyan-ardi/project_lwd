<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'webCont@index');
Route::get('/daftar', 'webCont@daftar');
Route::post('/pendaftaran', 'webCont@pendaftaran');
Route::get('/admin', 'adminCont@index');
Route::get('/kegiatan', 'adminCont@kegiatan');
Route::get('/tambah', 'adminCont@tambah');
Route::get('/detail/{id}', 'adminCont@detail');
Route::get('/status/{id}', 'adminCont@status');
Route::get('/hapus/{id}', 'adminCont@hapus');
Route::get('/home', 'adminCont@home');
Route::post('/tambahKegiatan', 'adminCont@tambahKegiatan');
Route::post('/prosesLogin', 'adminCont@prosesLogin');
Route::get('/pesan', 'FlashMessageController@index');
Route::get('/get-pesan', 'FlashMessageController@pesan');
Route::get('/logout', 'adminCont@logout');