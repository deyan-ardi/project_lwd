@extends('master')
@section('judul')
    Daftar Kepanitiaan
@endsection
@section('body')
<div class="row col-lg-12 mt-5 justify-content-center">
    <div class="col-lg-6 text-center">
        <img src="img/hmj.png" width="120px">
        <h3 style="font-family: 'Titillium Web', sans-serif; ">
            <i class="fas fa-quote-right"></i> FORM <span>PENDAFTARAN</span></h3>
        <hr width="20%">
    </div>
<div class="row col-lg-12 mt-5 mb-5">
    <div class="col-lg-6">
@if(Session::has('gagal'))
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <i class="fas fa-exclamation-triangle"></i> <strong>Opss... Something Wrong!!</strong> <br>
        {{ Session::get('gagal') }}
    </div>
@endif
@if(Session::has('berhasil'))
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <i class="far fa-check-circle"></i> <strong>Success!!</strong> <br>
        {{ Session::get('berhasil') }}
    </div>
@endif
    <form class="needs-validation" action="{{url('/pendaftaran')}}" method="POST" novalidate>
                {{csrf_field()}}
                <div class="form-group">
                    <label for="nim">NIM <span style="color:red;">*</span></label>
                    <input type="number" class="form-control" min="1810000000" max="1919999999" id="nim" name="nim"
                        placeholder="Masukkan Nim" required>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <div class="form-group">
                    <label for="nama-lengkap">Nama Lengkap <span style="color:red;">*</span></label>
                    <input type="text" class="form-control" id="nama-lengkap" name="nama_lengkap"
                        placeholder="Masukkan Nama Lengkap" required>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <div class="form-group">
                    <label for="prodi">Prodi <span style="color:red;">*</span></label>
                    <select class="form-control" id="prodi" name="prodi" required>
                        <option value="">Pilih Program Studi</option>
                        <option value="Sistem Informasi">Sistem Informasi</option>
                        <option value="Pendidikan Teknik Informatika">Pendidikan Teknik Informatika</option>
                        <option value="Ilmu Komputer">Ilmu Komputer</option>
                        <option value="Manajemen Informatika">Manajemen Informatika</option>
                    </select>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <div class="form-group">
                    <label for="panitia">Pilih Kepanitiaan <span style="color:red;">*</span></label>
                    <select class="form-control" id="panitia" name="panitia" required>
                        <option value="">Pilih Kepanitiaan</option>
                        @foreach ($var_kegiatan as $data)
                            @if ($data->status == "tutup");
                                @php
                                    echo '<option value="'.$data->id.'" disabled>'.$data->nama.'</option>';
                                @endphp
                            @else
                                @php
                                    echo '<option value="'.$data->id.'">'.$data->nama.'</option>';
                                @endphp
                            @endif
                        @endforeach
                    </select>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <button class="btn btn-primary" type="submit">Daftar Sekarang</button>
                <button class="btn btn-danger" type="reset">Batal</button>
            </form>
        </div>
    </div>
</div>
@endsection
