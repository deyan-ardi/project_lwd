<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- Botstrap CSS --}}
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    {{-- Style --}}
    <link rel="stylesheet" href="css/style.css">
    {{-- Font Awesome --}}
    <script src="https://kit.fontawesome.com/fd8370ec87.js" crossorigin="anonymous"></script>
    {{-- Google Fonts --}}
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="img/hmj.png" type="image/x-icon">
    <title>WEB HMJ TI :: @yield('judul')</title>
</head>
<body>
<section>
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark navbar-color">
        <div class="container">
        <a class="navbar-brand" href="#"><img src="img/hmj.png" width="45px"> HMJ TI UNDIKSHA</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item {{ Request::is('/') ? 'active' : '' }}">
              <a class="nav-link" href="{{ url('/') }}"><i class="fas fa-home"></i> Home<span
                class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item {{ Request::is('daftar') ? 'active' : '' }}">
              <a class="nav-link" href="{{ url('daftar') }}"><i class="fas fa-list"></i> Daftar HMJ</a>
            </li>
          </ul>
        </div>
    </div>
      </nav>
</section>
    <section id="slide" class="mt-5">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/slides/12.jpg" class="d-block w-100">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="pt-2 pr-2 pl-2 pb-2" >
                            <h1>SELAMAT DATANG DI WEBSITE PENDAFTARAN KEPANITIAAN HMJ TI UNDIKSHA</h1>
                        </div>
                        <a href="/daftar"><button type="button" class="btn btn-primary mt-2">Daftar
                                Kepanitiaan</button></a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="/img/slides/2.jpg" class="d-block w-100">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="pt-2 pr-2 pl-2 pb-2" >
                            <h1>SELAMAT DATANG DI WEBSITE PENDAFTARAN KEPANITIAAN HMJ TI UNDIKSHA</h1>
                        </div>
                        <a href="/daftar"><button type="button" class="btn btn-primary mt-2">Daftar
                                Kepanitiaan</button></a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="/img/slides/3.jpg" class="d-block w-100">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="pt-2 pr-2 pl-2 pb-2" >
                            <h1>SELAMAT DATANG DI WEBSITE PENDAFTARAN KEPANITIAAN HMJ TI UNDIKSHA</h1>
                        </div>
                        <a href="/daftar"><button type="button" class="btn btn-primary mt-2">Daftar
                                Kepanitiaan</button></a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="/img/slides/4.jpg" class="d-block w-100">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="border-box pt-2 pr-2 pl-2 pb-2" >
                            <h1>SELAMAT DATANG DI WEBSITE PENDAFTARAN KEPANITIAAN HMJ TI UNDIKSHA</h1>
                        </div>
                        <a href="/daftar"><button type="button" class="btn btn-primary mt-2">Daftar
                                Kepanitiaan</button></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

@yield('kepengurusan')
<div class="container">
    @yield('body')
</div>
<section id="footer-text-web">
    <div class="row col-lg-12 justify-content-center">
        <div class="col-lg-12 mt-5 text-center">
            <h3 style="font-family: 'Titillium Web', sans-serif; ">PENDAFTARAN KEPANITIAAN KEGIATAN HMJ TI UNDIKSHA</h3>
            <h4>Dilaksanakan Oleh :</h4>
            <hr width="20%">
            <h5>Pengurus Himpunan Mahasiswa Jurusan Teknik Informatika <br> Masa Bakti 2020-2021 <br> Fakultas Teknik dan
                Kejuruan <br> Universitas Pendidikan Ganesha</h5>
            <p>Alamat : Kampus Tengah, Jalan Udayana no. 11, Singaraja Bali</p>
            <p>Email : hmjtiundiksha@gmail.com | Ig : @hmj_ti.undiksha | Youtube : HMJ TI Undiksha | Fb :
                Hmj_Ti.Undiksha</p>
        </div>
    </div>
</section>
<section id="cp">
    <div class="row col-lg-12 pt-3 justify-content-lg-center justify-content-center">
        <div class="col-lg-4 text-center text-lg-left">
            <p>Made With <i class="fas fa-heart love"></i> For You</p>
        </div>
        <div class="col-lg-4 text-center">
            <p>Copyright &copy 2020.HMJ TI Undiksha - All Right Reserved</p>
        </div>
        <div class="col-lg-4 col-12">
            <div class="row justify-content-lg-end justify-content-center">
                <div class="col-lg-1 col-1">
                    <a href="mailto:hmjtiundiksha@gmail.com"><i class="fas fa-envelope email"></i></a>
                </div>
                <div class="col-lg-1 col-1">
                    <a href="https://www.instagram.com/hmj_ti.undiksha/"><i class="fab fa-instagram instagram"></i></a>
                </div>
                <div class="col-lg-1 col-1">
                    <a href="https://www.youtube.com/channel/UCjvKksTEifUWNU_rfCHubDg"><i
                            class="fab fa-youtube youtube"></i></a>
                </div>
                <div class="col-lg-1 col-1">
                    <a href="https://web.facebook.com/hmjti.undiksha?_rdc=1&_rdr"><i
                            class="fab fa-facebook-square facebook"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
{{-- Boostrap JS --}}
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="js/script.js"></script>
</body>
</html>
