@extends('admin/admin')

@section('judul')
    Dashboard
@endsection

@section('body')
<div class="jumbotron mt-3">
<h1 class="display-5">Hallo, Admin <span>{{Session::get('nama')}}</span></h1>
    <h4>Selamat Datang di Sistem Pendaftaran Kepanitiaan Kegiatan HMJ TI</h4>
    <hr class="my-4">
    <h5 class="mb-5">Website Pendaftaran Kepanitiaan Kegiatan <span>|</span> UTS Pemrograman Web Lanjut Semester 4 <span>|</span> Program Studi Sistem Informasi</h5>
    <table class="table table-borderless col-lg-6">
            <tbody>
                <tr>
                    <td>User Id Anda</td>
                    <td>:</td>
                    <td>{{Session::get('nim')}}</td>
                </tr>
                <tr>
                    <td>Nama Anda</td>
                    <td>:</td>
                    <td>{{Session::get('nama')}}</td>
                </tr>
                <tr>
                    <td>Jabatan</td>
                    <td>:</td>
                    <td>{{Session::get('jabatan')}}</td>
                </tr>
            </tbody>
        </table>
    <a class="btn btn-primary btn-md" href="/kegiatan" role="button">Data Kegiatan</a>
  </div>
@endsection
