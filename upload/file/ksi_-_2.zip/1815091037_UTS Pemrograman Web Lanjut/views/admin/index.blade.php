@extends('admin/login')
@section('judul')
    Login Admin
@endsection
@section('body')
<div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-8 col-sm-6 pt-4 pr-4 pl-4 pb-5 login">
                <div class="well login-box">
                    <form action="{{url('/prosesLogin')}}" method="POST" class="needs-validation" novalidate>
                        {{csrf_field()}}
                        <div class="row justify-content-center">
                            <img src="/img/hmj.png" alt="" class="logo rounded-circle">
                        </div>
                        <h1 class="text-center pt-3">
                            Login
                        </h1>
                        @if(Session::has('gagal'))
                            <div class="alert alert-danger">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <i class="fas fa-exclamation-triangle"></i></i> <strong>Oppss... Something Wrong!!</strong> <br>
                                {{ Session::get('gagal') }}
                            </div>
                        @endif
                        <div class="form-group">
                            <label for="userid">Admin ID</label>
                            <input id="userid" placeholder="Input User ID" type="text" class="form-control"
                                autocomplete="off" name="username" required />
                            <div class="invalid-feedback">
                                The Form Is Required!!
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input id="password" value='' placeholder="Input Password" type="password"
                                class="form-control" name="password" autocomplete="off" required />
                            <div class="invalid-feedback">
                                The Form Is Required!!
                            </div>
                        </div>
                        <div class="form-group text-center">
                            <button class="btn btn-primary" name="Submit" type="submit" value="Submit"
                                href="">Login</button>
                            <button class="btn btn-danger btn-cancel-action" type="reset">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
