@extends('admin/admin')
@section('judul')
    Detail Kegiatan
@endsection

@section('body')
<div class="jumbotron mt-3">
<h1 class="display-5">Detail Kegiatan <span>{{$var_kegiatan[0]->nama}}</span></h1>
    <hr class="my-4">
    <div class="table-responsive col-lg-12">
    <table id="dataTables2" class="display table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Program Studi</th>
            </tr>
        </thead>
        <tbody>
            @php
                $i = 1;
            @endphp
            @foreach ($var_anggota as $item)
                <tr>
                <td>{{$i++}}</td>
                <td>{{$item->nim}}</td>
                <td>{{$item->nama}}</td>
                <td>{{$item->prodi}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
<a class="btn btn-success btn-md mb-3" href="/kegiatan" role="button">Kembali</a>
</div>
@endsection
