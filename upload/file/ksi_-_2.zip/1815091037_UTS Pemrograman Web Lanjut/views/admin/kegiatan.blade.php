@extends('admin/admin')

@section('judul')
    Data Kegiatan
@endsection
@section('body')
<div class="jumbotron mt-3">
        <h1 class="display-5">Daftar Kegiatan <span>Keseluruhan</span></h1>
        <hr class="my-4">
        @if(Session::has('berhasil'))
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <i class="fas fa-exclamation-circle"></i> <strong>Success</strong> <br>
                {{ Session::get('berhasil') }}
            </div>
        @endif
        <a class="btn btn-primary btn-md mb-3" href="/tambah" role="button">Tambah Kegiatan</a>
    <div class="table-responsive col-lg-12">
        <table id="dataTables" class="display table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Kegiatan</th>
                    <th>Tanggal Kegiatan</th>
                    <th>Jumlah Pendaftar</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $i = 1;
                @endphp
                @foreach ($kegiatan as $data)
                    <tr>
                    <td>{{$i++}}</td>
                    <td>{{$data->nama}}</td>
                    <td>{{$data->tanggal}}</td>
                    <td>{{$data->sisa}} dari {{$data->kuota}}</td>
                    <td>{{$data->status}}</td>
                    <td><a href="/status/{{$data->id}}"><button type="button" class="btn btn-success btn-sm">Ubah Status</button></a>
                        <a href="/detail/{{$data->id}}"><button type="button" class="btn btn-warning btn-sm">Detail</button></a>
                        <a href="/hapus/{{$data->id}}"><button type="button" class="btn btn-danger btn-sm">Hapus</button></a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
