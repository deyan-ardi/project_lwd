@extends('admin/admin')

@section('judul')
    Tambah Data Kegiatan
@endsection

@section('body')
<div class="jumbotron mt-3">
    <h1 class="display-5">Tambah Kegiatan <span>HMJ TI</span></h1>
    <hr class="my-4">
    <div class="col-lg-6">
        <form class="needs-validation" action="{{url('/tambahKegiatan')}}" method="POST" novalidate>
            {{csrf_field()}}
                <div class="form-group">
                    <label for="nama-kegiatan">Nama Kegiatan <span style="color:red;">*</span></label>
                    <input type="text" class="form-control" id="nama-kegiatan" name="nama_kegiatan"
                        placeholder="Masukkan Nama Kegiatan" required>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <div class="form-group">
                    <label for="tanggal">Tanggal Kegiatan <span style="color:red;">*</span></label>
                    <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <div class="form-group">
                    <label for="jumlah_pendaftar">Jumlah Pendaftar <span style="color:red;">*</span></label>
                    <input type="text" class="form-control" id="jumlah_pendaftar" name="jumlah_pendaftar"
                        placeholder="Masukkan Jumlah Maksimal Pendaftar" required>
                    <div class="invalid-feedback">
                        Form is Required
                    </div>
                </div>
                <button class="btn btn-primary" type="submit">Tambah Kegiatan</button>
                <button class="btn btn-danger" type="reset">Batal</button>
        </form>
    </div>
</div>
@endsection
