package com.hotel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.input.crudData;

public class Menu extends Main {
	public Menu() {
		
	}
	protected void disp(String c,String d) {
		System.out.println(c);
		System.out.println(d);
	}
	protected void disp(String c) {
		System.out.println(c);
	}
	protected void disp(int c) {
		System.out.println(c);
	}
	protected static void menu() throws IOException {
		Scanner input = new Scanner(System.in);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String pilih ;
        char cek = 'y';
        int tmp4;
        
 
        while (cek == 'y' || cek == 'Y') {
    		System.out.println("1.Customer");
    		System.out.println("2.Room");
    		System.out.println("3.Pemesanan dan Pembayaran");
    		System.out.println("4.Keluar");
            System.out.println("===========================================");
            System.out.print(" Pilih Aksi: ");
             pilih = br.readLine();    
                  if(!pilih.matches("[0-9]+")){
                   System. err.print("Pilihan Anda Salah, Mohon Masukan Angka!\n");                      
                  }else{
                	  tmp4 = Integer.parseInt(pilih);
                	  if(tmp4 == 4){
                		  break;
                	  }
	                switch (tmp4) {
		                case 1:		 
		                    while (cek == 'y' || cek == 'Y') {
			                    System.out.println("==========================");
			            		System.out.println("CUSTOMER");
			            		System.out.println("==========================");
			            		System.out.println("1.Input Customer");
			    	    		System.out.println("2.Show Customer");
			    	    		System.out.println("3.Update Customer");
			    	    		System.out.println("4.Delete Customer");
			    	    		System.out.println("5.Keluar");
			    	    		System.out.println("Masukkan Pilihan:");
			   	             pilih = br.readLine();    
			                  if(!pilih.matches("[0-9]+")){
			                   System. err.print("Pilihan Anda Salah, Mohon Masukan Angka!\n");                      
			                  }else{
			                	  tmp4 = Integer.parseInt(pilih);
			                	  if(tmp4 == 5){
			                		  break;
			                	  }
				                switch (tmp4) {
					                case 1:		 
					                   crudData.tamCustomers();
					                    break;
					 
					                case 2:
					                	crudData.liCustomers();
					                    break;
					 
					                case 3:
					                	crudData.ubCustomers();
					                    break;
			 
					                case 4:
					                	crudData.haCustomers();
					                    break;
					                default:
					                    System.err.println("Format Pilihan Salah!!");
					                    break;
					            }

					        }   
			                   System.out.println("Ke Menu Customer ? [y/t]  ");
				               cek = input.next().charAt(0);
		                    } 
		                    break;
		 
		                case 2:
		                	while (cek == 'y' || cek == 'Y') {
		                	System.out.println("==========================");
		        			System.out.println("ROOM");
		        			System.out.println("==========================");
		        			System.out.println("Tipe Ruangan");
		        			System.out.println("1. VVIP");
		        			System.out.println("2. VIP");
		        			System.out.println("3. Keluar");
		        			System.out.println("Input Tipe");
		        			pilih = br.readLine();
		        			if(!pilih.matches("[0-9]+")){
				               System. err.print("Pilihan Anda Salah, Mohon Masukan Angka!\n");                      
				            }else{
				               tmp4 = Integer.parseInt(pilih);
				            if(tmp4 == 3){
				               break;
				            }
					        switch (tmp4) {
					        	case 1 :
					        	     while (cek == 'y' || cek == 'Y') {
						                    System.out.println("==========================");
						            		System.out.println("ROOM VVIP");
						            		System.out.println("==========================");
						            		System.out.println("1.Input ROOM VVIP");
						    	    		System.out.println("2.Show ROOM VVIP");
						    	    		System.out.println("3.Update ROOM VVIP");
						    	    		System.out.println("4.Delete ROOM VVIP");
						    	    		System.out.println("5.Keluar");
						    	    		System.out.println("Masukkan Pilihan:");
						   	             pilih = br.readLine();    
						                  if(!pilih.matches("[0-9]+")){
						                   System. err.print("Pilihan Anda Salah, Mohon Masukan Angka!\n");                      
						                  }else{
						                	  tmp4 = Integer.parseInt(pilih);
						                	  if(tmp4 == 5){
						                		  break;
						                	  }
							                switch (tmp4) {
								                case 1:		 
								                crudData.inVvip();
								                    break;
								 
								                case 2:
								                crudData.liVvip();
								                    break;
								 
								                case 3:
								                crudData.ubVvip();
								                    break;
						 
								                case 4:
								                crudData.haVvip();       
								                    break;
								                default:
								                    System.err.println("Format Pilihan Salah!!");
								                    break;
								            }
								        }   
						                   System.out.println("Kemenu Pilih Room ? [y/t]  ");
							               cek = input.next().charAt(0);
					                    }
				        			
				        			break;
					        	case 2 :
					        		while (cek == 'y' || cek == 'Y') {
					                    System.out.println("==========================");
					            		System.out.println("ROOM VIP");
					            		System.out.println("==========================");
					            		System.out.println("1.Input ROOM VIP");
					    	    		System.out.println("2.Show ROOM VIP");
					    	    		System.out.println("3.Update ROOM VIP");
					    	    		System.out.println("4.Delete ROOM VIP");
					    	    		System.out.println("5.Keluar");
					    	    		System.out.println("Masukkan Pilihan:");
					   	             pilih = br.readLine();    
					                  if(!pilih.matches("[0-9]+")){
					                   System. err.print("Pilihan Anda Salah, Mohon Masukan Angka!\n");                      
					                  }else{
					                	  tmp4 = Integer.parseInt(pilih);
					                	  if(tmp4 == 5){
					                		  break;
					                	  }
						                switch (tmp4) {
							                case 1:		 
							                	crudData.inVip();
							                    break;
							 
							                case 2:
							                	crudData.liVip();
							                    break;
							 
							                case 3:
							                	crudData.ubVip();
							                    	break;
					 
							                case 4:
							                	crudData.haVip();        
							                    break;
							                default:
							                    System.err.println("Format Pilihan Salah!!");
							                    break;
							            }

							        }   
					                   System.out.println("Kemenu Pilih Room ? [y/t]  ");
						               cek = input.next().charAt(0);
				                    }
			        			
			        			break;
				        			
					                
					            default:
					            	System.out.println("Salah");
					            }
					        }
		        			  System.out.println("Ingin Melanjutkan Lagi ? [y/t]  ");
				               cek = input.next().charAt(0);
		                	}
		        			
		                    break;
		 
		                case 3:
		                	crudData.pemesanan();
		                    break;
		                default:
		                    System.err.println("Format Pilihan Salah!!");
		                    break;
		            }
		            System.out.print("Ke Menu Home ? [y/t]");
		            cek = input.next().charAt(0);
		           
		             
		 
		        }
	        }
	}
}
