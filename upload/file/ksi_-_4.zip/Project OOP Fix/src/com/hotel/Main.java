package com.hotel;
public class Main {
	static Menu utama;
	protected Main(){
		System.out.println("copyright.2019 Sifors Undiksha\n");
	}
	public static void main(String[] args) throws Exception {
		Menu obj = new Menu();
		utama = new Menu();
		System.out.println("===========================================");
		System.out.println("SELAMAT DATANG DI SISTEM INFORMASI HOTEL");
		obj.disp("HOTEL PERJUANGAN SKS");
		obj.disp(2019);
		System.out.println("===========================================");
		Menu.menu();
		obj.disp("\nBYE","copyright.2019 Sifors Undiksha\n");
		 
	 }
}