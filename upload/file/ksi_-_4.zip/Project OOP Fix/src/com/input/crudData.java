package com.input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.hotel.Main;

public class crudData {
	
	private static int totPend;   
	 static int total;
	 public static int getTotPend() {
		return totPend;
	}
	public static void setTotPend(int totPend) {
		crudData.totPend = totPend;
	}
    static Scanner input = new Scanner(System.in);
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String pilih ;
    static String ktp[] = new String[30];
    static String nama[] = new String[30];
    static String alamat[] = new String[30];
    static String noA[] = new String[30];
    static String namaA[] = new String[30];
    static String noB[] = new String[30];
    static String namaB[] = new String[30];
    static String pemesananKtp[] = new String[30];
    static String pemesananHotelA[] = new String[30];
    static String pemesananHotelB[] = new String[30];
    static String pemesananLamaA[] = new String[10];
    static String pemesananLamaB[] = new String[10];
    static int data = 1;
    static int pemesanan;
   
    static int tmp1, tmp2, tmp4,tmp5, k = 1;
    static int j,i = 1;
    static String ubah ;
	static crudData utama;
	public static void tamCustomers() throws IOException {
		 char cek = 'y';
		 while (cek == 'y' || cek == 'Y') {
            System.out.println("==========================");
     		System.out.println("TAMBAH DATA CUSTOMER");
     		System.out.println("==========================");
               data++;
                 tmp1 = i;
                     for (i = tmp1; i <data; i++) {
                         System.out.println("Data Karyawan Ke : " + i);
                         System.out.print("KTP		: ");
                         ktp[i] = br.readLine();
                         if(!ktp[i].matches("[0-9 ]+")){
                             System.err.println("Format KTP Salah!!");
                             data--;
                             break;
                         }
                         System.out.print("Nama		: ");
                         nama[i] = br.readLine();
                          if(!nama[i].matches("[a-zA-Z_ -]+")){
                             System.err.println("Format Nama Salah!!");
                             data--;
                             break;
                         }
                         System.out.print("Alamat		: ");
                         alamat[i] = br.readLine();
                         //String toString = String.valueOf(gaji[i]);
                          if(alamat[i].matches("[0-9]+")){
                             System.err.println("Format Alamat Salah");
                             data--;
                             break;
                         }
                     System.out.println("\n");
                     }               
                 System.out.println("Data Berhasil Ditambahkan");
                 System.out.println("Ingin Tambah Data Lagi ? [y/t] : ");
                 cek = input.next().charAt(0);
             }
	}
	public static void liCustomers() {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("LIHAT DATA CUSTOMER");
		System.out.println("==========================");
        if(data == 1){
            System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
            System.out.println("No.	|\tNIK.		|\tNama.		|\tAlamat.\n");
            System.out.println("---------------------------------------------------");
            for ( j = 1; j < data; j++) {
                System.out.print("|"+j + "\t");
                System.out.print("|"+ktp[j]				+ "\t");
                System.out.print("|"+nama[j] 							+ "\t");
                System.out.print("|"+alamat[j] 							+ "\n");
            }
            System.out.println("---------------------------------------------------");
        }
	}
	public static void ubCustomers() throws IOException {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("UBAH DATA CUSTOMER");
		System.out.println("==========================");
        if(data == 1){
        	 System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
         
        	System.out.println("No.	|\tNIK.		|\tNama.		|\tAlamat.\n");
        	System.out.println("---------------------------------------------------");
            for ( j = 1; j < data; j++) {
            	System.out.print("|"+j + "\t");
                System.out.print("|"+ktp[j] + "\t");
                System.out.print("|"+nama[j] + "\t");
                System.out.print("|"+alamat[j] + "\n");
            }
            System.out.println("---------------------------------------------------");
            System.out.println("\n");
       while(cek == 'y' || cek == 'Y'){
        System.out.print("Pilih Data Yang Ingin Diubah : ");
         	ubah = br.readLine();
         	  if(!ubah.matches("[0-9]+")){
         		System.err.println("Format Pilihan Salah!!");
                   
              }else{
                tmp5 = Integer.parseInt(ubah);
                tmp2 = data;
                for (k = tmp5; k < tmp2; k++) {
                    System.out.print("KTP : ");
                    ktp[k] = br.readLine();
                     if(ktp[k].matches("[a-zA-Z_ ]+")){
                            System.err.println("Format KTP Salah!!\n");
                            tmp2--;
                            break;        
                        }
                    System.out.print("Nama : ");
                    nama[k] = br.readLine();
                     if(!nama[k].matches("[a-zA-Z_ ]+")){
                            System.err.println("Format Nama Salah!!\n");
                            tmp2--;
                            break;		 
                        }
                    System.out.print("Alamat : ");
                    alamat[k] = br.readLine();
                 if(alamat[k].matches("[0-9]+")){
                            System.err.println("Format Alamat Salah!!\n");
                            tmp2--;
                      	}
                    tmp2 -= tmp2;
                		}
              		}
         	  	
                   System.out.print("Ingin Ubah Data Lagi? [y/t]");
                   cek = input.next().charAt(0);
       			}
           }
	}
	public static void haCustomers() {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("HAPUS DATA CUSTOMER");
		System.out.println("==========================");
        System.out.println("\n");
        while(cek == 'y' || cek == 'Y'){
        if(data == 1){
            System.err.println("\nData Masih Kosong, Silahkan Masukkan Data!!\n");
            break;
        }else{
            data--;
            i--;
        if(i<1){
            i++;
        }
        if(data<1){
            data++;
        }             
        System.out.println("No.	|\tNIK.		|\tNama.		|\tAlamat.\n");
        System.out.println("---------------------------------------------------");
        for ( j = 1; j < data; j++) {
        	System.out.print("|"+j + "\t");
            System.out.print("|"+ktp[j] + "\t");
            System.out.print("|"+nama[j] + "\t");
            System.out.print("|"+alamat[j] + "\n");
        }	  
       
        System.out.println("---------------------------------------------------");
           System.out.println("Data Ke " +data+ " Berhasil di Hapus ");
          System.out.print("Ingin Hapus Data lagi ? [y/t]");
          cek = input.next().charAt(0);            
        	}
        }         
	}
	public static void inVvip() throws IOException {
		 char cek = 'y';
	    while (cek == 'y' || cek == 'Y') {
            System.out.println("==========================");
    		System.out.println("TAMBAH DATA ROOM VVIP");
    		System.out.println("==========================");
              data++;
                tmp1 = i;
                    for (i = tmp1; i <data; i++) {
                        System.out.println("Data Ruangan Ke : " + i);
                        System.out.print("Kode Ruangan		: ");
                        noA[i] = br.readLine();
                        if(!noA[i].matches("[0-9 ]+")){
                            System.err.println("Format Kode Salah!!");
                            data--;
                            break;
                        }
                        System.out.print("Nama Ruangan		: ");
                        namaA[i] = br.readLine();
                         if(!namaA[i].matches("[a-zA-Z_ -]+")){
                            System.err.println("Format Nama Salah!!");
                            data--;
                            break;
                        }
                    System.out.println("\n");
                    }               
                System.out.println("Data Berhasil Ditambahkan");
                System.out.println("Ingin Tambah Data Lagi ? [y/t] : ");
                cek = input.next().charAt(0);
            }
	}
	public static void liVvip() {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("LIHAT DATA ROOM VVIP");
		System.out.println("==========================");
        if(data == 1){
            System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
            System.out.println("No.	|\tKode.		|\tNama.	\n");
            System.out.println("---------------------------------------------------");
            for ( j = 1; j < data; j++) {
                System.out.print("|"+j + "\t");
                System.out.print("|"+noA[j]				+ "\t");
                System.out.print("|"+namaA[j] 							+ "\t");
                System.out.println("\n");
            }
            System.out.println("---------------------------------------------------");
        }
	}
	public static void ubVvip() throws IOException {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("UBAH DATA ROOM VVIP");
		System.out.println("==========================");
        if(data == 1){
        	 System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
         
        	 	System.out.println("No.	|\tKode.		|\tNama.	\n");
                System.out.println("---------------------------------------------------");
                for ( j = 1; j < data; j++) {
                    System.out.print("|"+j + "\t");
                    System.out.print("|"+noA[j]				+ "\t");
                    System.out.print("|"+namaA[j] 							+ "\t");
                    System.out.println("\n");
                }
                System.out.println("---------------------------------------------------");
       
            
       while(cek == 'y' || cek == 'Y'){
        System.out.print("Pilih Data Yang Ingin Diubah : ");
         	ubah = br.readLine();
         	  if(!ubah.matches("[0-9]+")){
         		System.err.println("Format Pilihan Salah!!");
                   
              }else{
                tmp5 = Integer.parseInt(ubah);
                tmp2 = data;
                for (k = tmp5; k < tmp2; k++) {
                    System.out.print("Kode Ruangan : ");
                    noA[k] = br.readLine();
                     if(noA[k].matches("[a-zA-Z_ ]+")){
                            System.err.println("Format Kode Salah!!\n");
                            tmp2--;
                            break;        
                        }
                    System.out.print("Nama : ");
                    namaA[k] = br.readLine();
                     if(!namaA[k].matches("[a-zA-Z_ ]+")){
                        System.err.println("Format Nama Salah!!\n");
                        tmp2--;
                        break;		 
                        }
                    tmp2 -= tmp2;
                		}
              		}
                   System.out.print("Ingin Ubah Data Lagi? [y/t]");
                   cek = input.next().charAt(0);
       			}
          }
	}
	public static void haVvip() {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("HAPUS DATA ROOM VVIP");
		System.out.println("==========================");
        System.out.println("\n");
        while(cek == 'y' || cek == 'Y'){
        if(data == 1){
            System.err.println("\nData Masih Kosong, Silahkan Masukkan Data!!\n");
            break;
        }else{
            data--;
            i--;
        if(i<1){
            i++;
        }
        if(data<1){
            data++;
        }             
        System.out.println("No.	|\tKode.		|\tNama.	\n");
        System.out.println("---------------------------------------------------");
        for ( j = 1; j < data; j++) {
            System.out.print("|"+j + "\t");
            System.out.print("|"+noA[j]				+ "\t");
            System.out.print("|"+namaA[j] 							+ "\t");
            System.out.println("\n");
        }
        System.out.println("---------------------------------------------------");
           System.out.println("Data Ke " +data+ " Berhasil di Hapus ");
          System.out.print("Ingin Hapus Data lagi ? [y/t]");
          cek = input.next().charAt(0);            
        	}
        }  
	}
	public static void inVip() throws IOException {
		 char cek = 'y';
		 while (cek == 'y' || cek == 'Y') {
             System.out.println("==========================");
     		System.out.println("TAMBAH DATA ROOM VIP");
     		System.out.println("==========================");
               data++;
                 tmp1 = i;
                     for (i = tmp1; i <data; i++) {
                         System.out.println("Data Ruangan Ke : " + i);
                         System.out.print("Kode Ruangan		: ");
                         noB[i] = br.readLine();
                         if(!noB[i].matches("[0-9 ]+")){
                             System.err.println("Format Kode Salah!!");
                             data--;
                             break;
                         }
                         System.out.print("Nama Ruangan		: ");
                         namaB[i] = br.readLine();
                          if(!namaB[i].matches("[a-zA-Z_ -]+")){
                             System.err.println("Format Nama Salah!!");
                             data--;
                             break;
                         }
                     System.out.println("\n");
                     }               
                 System.out.println("Data Berhasil Ditambahkan");
                 System.out.println("Ingin Tambah Data Lagi ? [y/t] : ");
                 cek = input.next().charAt(0);
             }
	}
	public static void liVip() {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("LIHAT DATA ROOM VIP");
		System.out.println("==========================");
        if(data == 1){
            System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
            System.out.println("No.	|\tKode.		|\tNama.	\n");
            System.out.println("---------------------------------------------------");
            for ( j = 1; j < data; j++) {
                System.out.print("|"+j + "\t");
                System.out.print("|"+noB[j]				+ "\t");
                System.out.print("|"+namaB[j] 							+ "\t");
                System.out.println("\n");
            }
            System.out.println("---------------------------------------------------");
        }
	}
	public static void ubVip() throws IOException {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("UBAH DATA ROOM VIP");
		System.out.println("==========================");
        if(data == 1){
        	 System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
         
        	 	System.out.println("No.	|\tKode.		|\tNama.	\n");
                System.out.println("---------------------------------------------------");
                for ( j = 1; j < data; j++) {
                    System.out.print("|"+j + "\t");
                    System.out.print("|"+noB[j]				+ "\t");
                    System.out.print("|"+namaB[j] 							+ "\t");
                    System.out.println("\n");
                }
                System.out.println("---------------------------------------------------");
       
            
       while(cek == 'y' || cek == 'Y'){
    	   
        System.out.print("Pilih Data Yang Ingin Diubah : ");
         	ubah = br.readLine();
         	  if(!ubah.matches("[0-9]+")){
         		System.err.println("Format Pilihan Salah!!");
                   
              }else{
                tmp5 = Integer.parseInt(ubah);
                tmp2 = data;
                for (k = tmp5; k < tmp2; k++) {
                    System.out.print("Kode Ruangan : ");
                    noB[k] = br.readLine();
                     if(noB[k].matches("[a-zA-Z_ ]+")){
                            System.err.println("Format Kode Salah!!\n");
                            tmp2--;
                            break;        
                        }
                    System.out.print("Nama : ");
                    namaB[k] = br.readLine();
                     if(!namaB[k].matches("[a-zA-Z_ ]+")){
                        System.err.println("Format Nama Salah!!\n");
                        tmp2--;
                        break;		 
                        }
                    tmp2 -= tmp2;
                		}
              		}
                   System.out.print("Ingin Ubah Data Lagi? [y/t]");
                   cek = input.next().charAt(0);
       			}
          }
	}
	public static void haVip() {
		 char cek = 'y';
		System.out.println("==========================");
		System.out.println("HAPUS DATA ROOM VIP");
		System.out.println("==========================");
        System.out.println("\n");
        while(cek == 'y' || cek == 'Y'){
        if(data == 1){
            System.err.println("\nData Masih Kosong, Silahkan Masukkan Data!!\n");
            break;
        }else{
            data--;
            i--;
        if(i<1){
            i++;
        }
        if(data<1){
            data++;
        }             
        System.out.println("No.	|\tKode.		|\tNama.	\n");
        System.out.println("---------------------------------------------------");
        for ( j = 1; j < data; j++) {
            System.out.print("|"+j + "\t");
            System.out.print("|"+noB[j]				+ "\t");
            System.out.print("|"+namaB[j] 							+ "\t");
            System.out.println("\n");
        }
        System.out.println("---------------------------------------------------");
           System.out.println("Data Ke " +data+ " Berhasil di Hapus ");
          System.out.print("Ingin Hapus Data lagi ? [y/t]");
          cek = input.next().charAt(0);            
        	}
        } 
	}
	public static void pemesanan() throws IOException {
		char cek = 'y';
		System.out.println("==========================");
		System.out.println("PEMESANAN");
		System.out.println("==========================");
		if(data == 1){
        	 System.err.println("Data Masih Kosong, Silahkan Masukkan Data!!");
        }else{
        		System.out.println("==================");
        		System.out.println("Data Customer");
        		System.out.println("==================");
        		System.out.println("\n");
        	 	System.out.println("No.	|\tKode.		|\tNama.		|\tAlamat.\n");
                System.out.println("---------------------------------------------------");
                for ( j = 1; j < data; j++) {
                    System.out.print("|"+j + "\t");
                    System.out.print("|"+ktp[j]				+ "\t");
                    System.out.print("|"+nama[j] 							+ "\t");
                    System.out.print("|"+alamat[j] 							+ "\t");
                    System.out.println("\n");
                }
                System.out.println("---------------------------------------------------");
                System.out.println("==================");
        		System.out.println("Data Hotel VVIP");
        		System.out.println("==================");
        		System.out.println("\n");
        	 	System.out.println("No.	|\tKode.		|\tNama.	\n");
                System.out.println("---------------------------------------------------");
                for ( j = 1; j < data; j++) {
                    System.out.print("|"+j + "\t");
                    System.out.print("|"+noA[j]				+ "\t");
                    System.out.print("|"+namaA[j] 							+ "\t");
                    System.out.println("\n");
                }
                System.out.println("---------------------------------------------------");
                System.out.println("==================");
        		System.out.println("Data Hotel VIP");
        		System.out.println("==================");
        		System.out.println("\n");
        	 	System.out.println("No.	|\tKode.		|\tNama.	\n");
                System.out.println("---------------------------------------------------");
                for ( j = 1; j < data; j++) {
                    System.out.print("|"+j + "\t");
                    System.out.print("|"+noB[j]				+ "\t");
                    System.out.print("|"+namaB[j] 							+ "\t");
                    System.out.println("\n");
                }
                System.out.println("---------------------------------------------------");
            
       while(cek == 'y' || cek == 'Y'){
    	   data++;
            tmp1 = i;
                for (i = tmp1; i <data; i++) {
                    System.out.println("Data Pesanan Ke : " + i);
                    System.out.print("Masukkan No KTP Pemesan	: ");
                    pemesananKtp[i] = br.readLine();
                    if(!pemesananKtp[i].matches("[0-9 ]+")){
                        System.err.println("Format Kode Salah!!");
                        data--;
                        break;
                    }
//                    System.out.println(pemesananKtp[i]);
                    System.out.println("Pilih Jenis Hotel");
                    System.out.println("1. VVIP");
                    System.out.println("2. VIP");
                    System.out.println("Masukkan Pilihan :");
                    ubah = br.readLine();
                    String equal = "1";
                    if(ubah.equals(equal)) {
                    	 System.out.print("Masukkan Kode Hotel	: ");
                         pemesananHotelA[i] = br.readLine();
                         if(!pemesananHotelA[i].matches("[0-9 ]+")){
                             System.err.println("Format Kode Salah!!");
                             data--;
                             break;
                         }
                         System.out.print("Lama Menginap	: ");
                         pemesananLamaA[i] = br.readLine();
                         if(!pemesananLamaA[i].matches("[0-9 ]+")){
                             System.err.println("Format Kode Salah!!");
                             data--;
                             break;
                         }
                         int lama = Integer.parseInt(pemesananLamaA[i]);
                         int hargaTot = 230000 * lama;
                         String pembayaran;
                         while(cek == 'y' || cek == 'Y'){
                         System.out.println("==========================================");
                         System.out.println("Total Biaya Pemesanan Rp."+hargaTot);
                         System.out.println("==========================================");
                         System.out.println("Masukkan Pembayaran :");
                         pembayaran = br.readLine();
                         int bayar = Integer.parseInt(pembayaran);
                         System.out.println("==========================================");
 	                        if(bayar >= hargaTot) {
 	                        	setTotPend(procHitung(lama, 230000));
 	                        	System.out.println("Kembalian Anda Adalah Rp."+procBayar(bayar,hargaTot));
 	                        	cek = 't';
 	                        }else{
 	                        	System.out.println("Uang Anda Tidak Cukup");
 	                        	 System.out.print("Ingin Ulang Lagi? [y/t]");
 	                             cek = input.next().charAt(0);
 	                        }
                         System.out.println("==========================================");
                         }
                     
                    }else {
                    	System.out.print("Masukkan Kode Hotel	: ");
                         pemesananHotelB[i] = br.readLine();
                         if(!pemesananHotelB[i].matches("[0-9 ]+")){
                             System.err.println("Format Kode Salah!!");
                             data--;
                             break;
                         }
                         System.out.print("Lama Menginap	: ");
                         pemesananLamaB[i] = br.readLine();
                         if(!pemesananLamaB[i].matches("[0-9 ]+")){
                             System.err.println("Format Kode Salah!!");
                             data--;
                             break;
                         }
                         int lama = Integer.parseInt(pemesananLamaB[i]);
                		 int hargaTot = 100000 * lama;
                        String pembayaran;
                        while(cek == 'y' || cek == 'Y'){
                        System.out.println("==========================================");
                        System.out.println("Total Biaya Pemesanan Rp."+hargaTot);
                        System.out.println("==========================================");
                        System.out.println("Masukkan Pembayaran :");
                        pembayaran = br.readLine();
                        int bayar = Integer.parseInt(pembayaran);
                        System.out.println("==========================================");
	                        if(bayar >= hargaTot) {
	                        	setTotPend(procHitung(lama, 100000));
	                        	System.out.println("Kembalian Anda Adalah Rp."+procBayar(bayar,hargaTot));
	                        	cek = 't';
	                        }else{
	                        	System.out.println("Uang Anda Tidak Cukup");
	                        	 System.out.print("Ingin Ulang Lagi? [y/t]");
	                             cek = input.next().charAt(0);
	                        }
                        System.out.println("==========================================");
                        }
                    }
                   System.out.println("==========================================");
                   System.out.println("Total Pendapatan Hotel Rp."+getTotPend());
                   System.out.println("==========================================");
                   System.out.print("Ingin Pilih Pemesanan dan Pembayaran Lagi? [y/t]");
                   cek = input.next().charAt(0);
       			}
             }
        }
	}
	public static int procBayar(int bayar, int pemesanan) {
		int jmlh = bayar, totKembali = 0;
		totKembali = jmlh - pemesanan;
		if(totKembali < 0) {
			return 0;
		}else {
			return totKembali;
		}
	}
	public static int procHitung(int lama, int harga) {
		int lamaHari = lama; 
		int hargaTot = harga * lamaHari;
        int totalHarga = 0;
        totalHarga = totalHarga + hargaTot;
        total = total + hargaTot;
        System.out.println(totalHarga);
        return total;
	}
}
